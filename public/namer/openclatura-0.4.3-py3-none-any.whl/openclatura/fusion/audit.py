"""Independent graph reconstruction and audit for systematic fusion plans.

The auditor consumes only typed fusion objects and molecular graphs.  It does
not inspect a rendered name and deliberately does not call the fusion planner
or component matcher, so it can detect corruption in either of those stages.
"""

from __future__ import annotations

from collections import Counter, defaultdict
from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from typing import Any

from ..locants import SystemLocant, system_locant_sort_key
from ..molecule import Molecule, edges_within_atoms
from ..polycycle_topology import normalize_edge
from ..retained_graph_model import merge_parent_bond_classes
from ..rules import multipliers
from .config import fusion_nomenclature_config
from .cover import audit_component_cover, component_scope
from .exocyclic import is_neutral_external_pi_ligand, neutral_lambda_oxo_bonding_number
from .indicated_hydrogen import (
    component_carbon_h_relocation_scope,
    component_parent_atoms,
    component_parent_graph,
    intrinsic_carbon_candidate_atoms,
    intrinsic_carbon_parent_model,
    intrinsic_parent_lone_pair_sites,
    is_intrinsic_carbon_h_site,
    released_fusion_carbon_sites,
)
from .mancude import (
    ParentDerivativeState,
    compare_actual_parent_to_implied_parent,
    has_complete_saturated_hydrogenation,
    indicated_hydrogen_parent_bond_model,
    is_added_hydrogen_nitrogen,
    prove_pi_redistribution,
    saturated_nitrogen_hydrogen_sites,
)
from .model import (
    AuditStatus,
    ComponentLocant,
    FusionAuditResult,
    FusionChargeOperation,
    FusionChargeOperationKind,
    FusionCitationNode,
    FusionCitationPlan,
    FusionComponentMatch,
    FusionComponentSpec,
    FusionDescriptor,
    FusionGraph,
    FusionJoin,
    FusionJoinKind,
    FusionMode,
    FusionNameAst,
    FusionNumberingProof,
    ParentBondModel,
)
from .numbering import (
    MancudeSearchBudgetExceeded,
    bond_model_indicated_hydrogen_atoms,
    indicated_hydrogen_candidate_atoms,
    parent_bond_model,
    validate_parent_bond_valence,
)
from .rules import (
    component_parent_eligible,
    component_spec_seniority_key,
    component_variant_identity,
    fusion_ring_size_gate,
    multiplicative_attachment_key,
    multiplicative_member_order_key,
)
from .valence import FusionLambdaDescriptor

_DIRECTED_SHAPE_IDS = frozenset(
    shape.shape_id for shape in fusion_nomenclature_config().ring_shapes if shape.directed_entry_port is not None
)

_Node = tuple[int, str]
_Edge = tuple[int, int]


@dataclass(frozen=True, slots=True)
class _ReconstructedGraph:
    input_atom_by_node: Mapping[_Node, int]
    skeleton_atom_by_node: Mapping[_Node, int]
    input_edges_by_occurrence: Mapping[int, frozenset[_Edge]]
    input_atoms: Mapping[int, tuple[str, int]]
    input_edges: frozenset[_Edge]
    skeleton_atoms: Mapping[int, tuple[str, int]]
    skeleton_edges: Mapping[_Edge, str]


class _DisjointSet:
    def __init__(self, values: Iterable[_Node]) -> None:
        self._parent = {value: value for value in values}

    def find(self, value: _Node) -> _Node:
        parent = self._parent[value]
        if parent != value:
            self._parent[value] = self.find(parent)
        return self._parent[value]

    def union(self, left: _Node, right: _Node) -> None:
        left_root = self.find(left)
        right_root = self.find(right)
        if left_root != right_root:
            self._parent[right_root] = left_root


def _unrepresented_component_indicated_hydrogens(
    ast: FusionNameAst,
    specs: Mapping[int, FusionComponentSpec],
    indicated_hydrogens: tuple[SystemLocant, ...],
    numbering: FusionNumberingProof,
    derivative_state: ParentDerivativeState | None = None,
) -> tuple[tuple[int, str], ...]:
    """Return component H sites neither consumed by fusion nor cited.

    Indicated hydrogen belongs initially to an independently named component.
    Fusion through that atom consumes the component-local state; otherwise the
    completed parent must cite the corresponding completed-system locant.
    """

    from .component_hydrogen import component_hydrogen_consumption

    consumption = component_hydrogen_consumption(ast, specs)
    consumed_defaults = consumption.default_sites if consumption is not None else frozenset()
    matches = {match.occurrence_id: match for match in ast.component_occurrences}
    fusion_atoms = frozenset(atom for join in ast.joins for atom in join.shared_input_atoms)
    completed_locants = {atom: str(locant) for atom, locant in numbering.input_locant_maps[0]}
    cited = {str(locant) for locant in indicated_hydrogens}
    converted = (
        {atom for operation in derivative_state.intrinsic_hydro_operations for atom in operation.atom_ids}
        if derivative_state is not None
        else set()
    )
    unresolved = []
    for occurrence, spec in specs.items():
        local = matches[occurrence].input_atom_by_locant
        for locant in spec.template.default_indicated_h:
            atom = local[locant]
            if (occurrence, locant) in consumed_defaults:
                continue
            if atom in fusion_atoms or atom in converted or completed_locants.get(atom) in cited:
                continue
            unresolved.append((occurrence, locant))
    return tuple(sorted(unresolved))


def audit_fusion_plan(
    mol: Molecule,
    parent_atom_ids: Iterable[int],
    *,
    ast: FusionNameAst,
    abstract_parent_graph: FusionGraph,
    numbering: FusionNumberingProof,
    bond_model: ParentBondModel,
    mode: FusionMode = FusionMode.GENERAL,
    registry: object | None = None,
    lambda_descriptors: tuple[FusionLambdaDescriptor, ...] = (),
    indicated_hydrogens: tuple[SystemLocant, ...] = (),
    charge_operations: tuple[FusionChargeOperation, ...] = (),
    derivative_state: ParentDerivativeState | None = None,
    rendered_core_name: str | None = None,
) -> FusionAuditResult:
    """Independently reconstruct and audit a completed fusion candidate.

    ``ABSTAIN`` is reserved for a nomenclatural applicability gate, currently
    the universal ring-size and PIN component-policy gates. A self-inconsistent proof or
    graph is a ``MISMATCH``.  Missing registry data and unexpected audit
    failures are reported as ``ERROR`` rather than allowing an unaudited name
    to enter rendering.
    """

    parent_atoms = frozenset(parent_atom_ids)
    unknown = parent_atoms - mol.atoms.keys()
    if unknown:
        return _error(f"selected parent references unknown atom ids: {sorted(unknown)}")
    if not parent_atoms:
        return _error("selected parent graph is empty")

    ring_sizes = tuple(face.size for face in numbering.selected_face_model.faces)
    if not fusion_ring_size_gate(ring_sizes):
        return FusionAuditResult(
            AuditStatus.ABSTAIN,
            checks=("fusion_ring_size_gate",),
            errors=("fewer than two rings of size at least five",),
        )

    try:
        specs = {match.occurrence_id: _component_spec(registry, match) for match in ast.component_occurrences}
    except (KeyError, TypeError, ValueError) as exc:
        return _error(str(exc))

    if mode is FusionMode.AUDITED_PIN:
        non_pin = sorted(occurrence for occurrence, spec in specs.items() if not spec.pin_component)
        if non_pin:
            return FusionAuditResult(
                AuditStatus.ABSTAIN,
                checks=("fusion_ring_size_gate", "pin_component_policy"),
                errors=(f"component occurrences are not PIN-eligible: {non_pin}",),
            )

        unresolved_component_h = _unrepresented_component_indicated_hydrogens(
            ast,
            specs,
            indicated_hydrogens,
            numbering,
            derivative_state,
        )
        if unresolved_component_h:
            return FusionAuditResult(
                AuditStatus.ABSTAIN,
                checks=("fusion_ring_size_gate", "pin_component_policy", "component_indicated_h_composition"),
                errors=(
                    "polycomponent fusion has unrepresented intrinsic indicated-hydrogen sites: "
                    f"{unresolved_component_h}",
                ),
            )

        composition_errors = _audited_pin_composition_errors(
            mol,
            ast,
            specs,
            numbering=numbering,
            indicated_hydrogens=indicated_hydrogens,
            derivative_state=derivative_state,
        )
        if composition_errors:
            return FusionAuditResult(
                AuditStatus.ABSTAIN,
                checks=("fusion_ring_size_gate", "pin_component_policy", "audited_composition_capability"),
                errors=composition_errors,
            )

    policy_errors = _component_role_errors(ast, specs)
    if policy_errors:
        return FusionAuditResult(AuditStatus.ABSTAIN, checks=("component_role_policy",), errors=policy_errors)

    errors: list[str] = []
    checks: list[str] = ["fusion_ring_size_gate"]
    if mode is FusionMode.AUDITED_PIN:
        checks.append("pin_component_policy")
    try:
        reconstruction = _reconstruct(ast, specs, mol, errors)
        _audit_nomenclature_selection(ast, specs, errors)
        checks.append("nomenclature_selection")
        _audit_component_and_face_coverage(
            mol,
            parent_atoms,
            ast,
            specs,
            numbering,
            reconstruction,
            errors,
        )
        checks.append("component_coverage")

        _audit_descriptors(mol, ast, specs, reconstruction, numbering, errors)
        checks.append("descriptor_interfaces")

        _audit_reconstructed_graph(
            mol,
            parent_atoms,
            abstract_parent_graph,
            reconstruction,
            charge_operations,
            errors,
        )
        checks.extend(("abstract_graph_reconstruction", "input_graph_identity"))
        _audit_component_pi_constraints(ast, specs, abstract_parent_graph, errors)

        _audit_numbering(mol, parent_atoms, abstract_parent_graph, numbering, charge_operations, errors, ast=ast)
        checks.append("completed_numbering")

        _audit_charge_operations(mol, parent_atoms, abstract_parent_graph, numbering, charge_operations, errors)
        checks.append("charge_operations")

        intrinsic_n_h = intrinsic_parent_lone_pair_sites(mol, abstract_parent_graph)
        cited_n_h = frozenset(
            atom
            for atom, locant in numbering.input_locant_maps[0]
            if locant in indicated_hydrogens
            and mol.atoms[atom].symbol == "N"
            and not mol.atoms[atom].charge
            and mol.atoms[atom].total_h_count == 1
        )
        carbon_candidates = intrinsic_carbon_candidate_atoms(ast, specs, mol)
        intrinsic_c_h = frozenset()
        released_c_junctions = released_fusion_carbon_sites(mol, abstract_parent_graph, carbon_candidates)
        if intrinsic_n_h or carbon_candidates or released_c_junctions:
            expected_model = (
                indicated_hydrogen_parent_bond_model(abstract_parent_graph, intrinsic_n_h)
                if intrinsic_n_h
                else parent_bond_model(abstract_parent_graph)
            )
            expected_model, intrinsic_c_h = intrinsic_carbon_parent_model(
                mol,
                abstract_parent_graph,
                expected_model,
                dict(numbering.input_locant_maps[0]),
                carbon_candidates,
                intrinsic_hydrogen_atom_ids=intrinsic_n_h,
                cited_nitrogen_hydrogen_atom_ids=cited_n_h,
            )
            if (intrinsic_n_h or intrinsic_c_h or released_c_junctions) and bond_model != expected_model:
                errors.append("parent bond model does not preserve the proved intrinsic-hydrogen sites")
        _audit_bond_model(abstract_parent_graph, bond_model, errors)
        checks.append("parent_bond_model")
        if derivative_state is None:
            errors.append("fusion parent has no typed derivative-state proof")
        else:
            _audit_derivative_state(
                mol,
                parent_atoms,
                numbering,
                bond_model,
                indicated_hydrogens,
                derivative_state,
                errors,
            )
        checks.append("parent_derivative_state")
        if derivative_state is not None:
            from .external_pi_consumption import has_paired_external_pi_consumption

            if has_paired_external_pi_consumption(mol, parent_atoms, derivative_state):
                checks.append("paired_external_pi_consumption")
        hydro_owned_h = (
            parent_atoms
            if not indicated_hydrogens
            and derivative_state is not None
            and has_complete_saturated_hydrogenation(mol, parent_atoms, derivative_state)
            else frozenset()
        )
        if derivative_state is not None:
            hydro_owned_h |= frozenset(
                atom
                for operation in derivative_state.hydro_operations + derivative_state.added_hydrogen_operations
                for atom in operation.atom_ids
            )
        _audit_indicated_hydrogens(
            mol, numbering, bond_model, indicated_hydrogens, errors, intrinsic_c_h, hydro_owned_h
        )
        checks.append("indicated_hydrogens")
        _audit_lambda_descriptors(mol, parent_atoms, numbering, lambda_descriptors, errors)
        checks.append("lambda_descriptors")
        if rendered_core_name is not None:
            from .descriptor import render_fusion_name

            if render_fusion_name(ast, registry) != rendered_core_name:
                errors.append("rendered fusion parent does not reproduce its context-free AST")
            checks.append("context_free_rendering")
    except (KeyError, TypeError, ValueError, MancudeSearchBudgetExceeded) as exc:
        return _error(f"fusion audit could not evaluate candidate: {exc}", checks=checks)

    if errors:
        return FusionAuditResult(AuditStatus.MISMATCH, checks=tuple(checks), errors=tuple(dict.fromkeys(errors)))
    return FusionAuditResult(AuditStatus.CONFIRMED, checks=tuple(checks))


def _audit_lambda_descriptors(
    mol: Molecule,
    parent_atoms: frozenset[int],
    numbering: FusionNumberingProof,
    descriptors: tuple[FusionLambdaDescriptor, ...],
    errors: list[str],
) -> None:
    """Check neutral nonstandard bonding numbers against the final locant map."""

    locants = dict(numbering.input_locant_maps[0])
    expected: dict[int, tuple[SystemLocant, int, int]] = {}
    for atom_id in parent_atoms:
        atom = mol.atoms[atom_id]
        if atom.charge or atom.is_carbon:
            continue
        bonding_number = (atom.total_h_count or atom.explicit_h_count) + sum(
            bond.order
            for neighbor in mol.get_neighbors(atom_id)
            if (bond := mol.get_bond(atom_id, neighbor)) is not None
        )
        if bonding_number > atom.element.standard_valence:
            expected[atom_id] = (locants[atom_id], bonding_number, atom.element.standard_valence)
    observed = {
        descriptor.atom_id: (
            descriptor.locant,
            descriptor.bonding_number,
            descriptor.standard_valence,
        )
        for descriptor in descriptors
    }
    if observed != expected:
        errors.append("lambda descriptors do not represent every neutral nonstandard-valence parent atom")


def _audit_charge_operations(
    mol: Molecule,
    parent_atoms: frozenset[int],
    abstract: FusionGraph,
    numbering: FusionNumberingProof,
    operations: tuple[FusionChargeOperation, ...],
    errors: list[str],
) -> None:
    """Verify that charge operations exactly explain observed parent charges."""

    locants = dict(numbering.input_locant_maps[0])
    base_atoms = {atom.id: atom for atom in abstract.atoms}
    expected = {
        atom_id: (base_atoms[atom_id].formal_charge, mol.atoms[atom_id].charge)
        for atom_id in parent_atoms
        if mol.atoms[atom_id].charge != base_atoms[atom_id].formal_charge
    }
    observed: dict[int, tuple[int, int]] = {}
    for operation in operations:
        if operation.atom_id not in parent_atoms or operation.atom_id not in base_atoms:
            errors.append("fusion charge operation targets an atom outside the parent graph")
            continue
        if operation.atom_id in observed:
            errors.append("fusion charge operations duplicate a charged atom")
            continue
        if operation.locant != locants.get(operation.atom_id):
            errors.append("fusion charge operation locant does not map to its charged atom")
        if operation.symbol != mol.atoms[operation.atom_id].symbol:
            errors.append("fusion charge operation does not preserve the charged atom element")
        if operation.operation_kind is FusionChargeOperationKind.DEPROTONATION:
            atom = mol.atoms[operation.atom_id]
            valence = atom.total_h_count + sum(
                mol.get_bond(atom.idx, neighbor).order for neighbor in mol.get_neighbors(atom.idx)
            )
            if (operation.base_charge, operation.observed_charge) != (0, -1) or valence != {"C": 3, "N": 2}.get(
                atom.symbol
            ):
                errors.append("fusion deprotonation does not preserve proton-removal valence")
        elif operation.operation_kind is FusionChargeOperationKind.HETEROATOM_CATIONIZATION:
            if operation.symbol not in {"N", "O"} or (operation.base_charge, operation.observed_charge) != (0, 1):
                errors.append("fusion cationization is not a neutral N/O to +1 operation")
        else:
            errors.append("fusion charge operation has an unsupported operation kind")
        observed[operation.atom_id] = (operation.base_charge, operation.observed_charge)
    if observed != expected:
        errors.append("fusion charge operations do not exactly represent parent formal-charge changes")


def _audit_nomenclature_selection(
    ast: FusionNameAst,
    specs: Mapping[int, FusionComponentSpec],
    errors: list[str],
) -> None:
    """Verify parent identity and intrinsic component seniority independently."""

    citation = _citation_plan(ast)
    if citation.parent_occurrences != ast.parent_occurrences:
        errors.append("fusion citation roots do not match the declared parent occurrences")
    if ast.citation_tree is not None and (len(citation.roots) != 1 or citation.roots[0] != ast.citation_tree):
        errors.append("legacy citation tree does not match the citation plan")
    parent_set = set(citation.parent_occurrences)
    if any(ast.joins[index].attached_occurrence in parent_set for index in citation.primary_join_indices):
        errors.append("a citation root is attached by a primary join")
    if any(ast.joins[index].kind is not FusionJoinKind.HIGHER_ORDER for index in citation.cycle_closing_join_indices):
        errors.append("a cycle-closing join lacks a higher-order descriptor")
    matches = {match.occurrence_id: match for match in ast.component_occurrences}
    if any(parent not in matches for parent in ast.parent_occurrences):
        errors.append("a declared fusion parent is absent from component occurrences")
        return
    eligible = [
        match
        for occurrence, match in matches.items()
        if component_parent_eligible(match, specs[occurrence], ast.component_occurrences)
    ]
    if not eligible:
        errors.append("fusion plan has no component eligible as a parent")
        return
    preferred = min(component_spec_seniority_key(specs[match.occurrence_id]) for match in eligible)
    if any(component_spec_seniority_key(specs[parent]) != preferred for parent in ast.parent_occurrences):
        errors.append("declared fusion parent is not the intrinsically senior eligible component")
    if len(ast.parent_occurrences) > 1:
        parent_variants = {component_variant_identity(specs[parent]) for parent in ast.parent_occurrences}
        if len(parent_variants) != 1:
            errors.append("multiparent citation does not use identical parent components")
        if not citation.interparent_occurrences:
            errors.append("multiparent citation has no explicit interparent component")


def _citation_plan(ast: FusionNameAst) -> FusionCitationPlan:
    if ast.citation_plan is not None:
        return ast.citation_plan
    if ast.citation_tree is None:
        raise ValueError("fusion AST has no citation structure")
    return FusionCitationPlan.from_tree(ast.citation_tree, ast.joins)


def _component_spec(registry: object | None, match: FusionComponentMatch) -> FusionComponentSpec:
    if registry is None:
        from .registry import fusion_component_registry

        registry = fusion_component_registry()

    resolver = getattr(registry, "spec_for_match", None)
    if resolver is not None:
        return resolver(match)
    value: Any = None
    by_key = getattr(registry, "by_key", None)
    if by_key is not None:
        value = by_key.get(match.spec_key)
    elif isinstance(registry, Mapping):
        value = registry.get(match.spec_key)
    else:
        getter = getattr(registry, "get", None)
        if getter is not None:
            value = getter(match.spec_key)
    value = getattr(value, "spec", value)
    if not isinstance(value, FusionComponentSpec):
        raise KeyError(f"unknown fusion component spec: {match.spec_key}")
    return value


def _component_role_errors(
    ast: FusionNameAst,
    specs: Mapping[int, FusionComponentSpec],
) -> tuple[str, ...]:
    parents = set(ast.parent_occurrences)
    matches = {match.occurrence_id: match for match in ast.component_occurrences}
    errors = []
    for occurrence, spec in specs.items():
        if occurrence in parents and not component_parent_eligible(
            matches[occurrence], spec, ast.component_occurrences
        ):
            errors.append(f"component occurrence {occurrence} is not allowed as a fusion parent")
        if occurrence not in parents and not spec.usable_as_attached:
            errors.append(f"component occurrence {occurrence} is not allowed as an attached component")
    return tuple(errors)


def _audited_pin_composition_errors(
    mol: Molecule,
    ast: FusionNameAst,
    specs: Mapping[int, FusionComponentSpec],
    *,
    numbering: FusionNumberingProof,
    indicated_hydrogens: tuple[SystemLocant, ...],
    derivative_state: ParentDerivativeState | None,
) -> tuple[str, ...]:
    """Return composition classes not yet proved for preferred-name output.

    GENERAL mode remains available for syntactically experimental fusion
    compositions. AUDITED_PIN requires an operation-local proof that survives
    composition, rather than treating graph reconstruction of the unrendered
    AST as proof of the rendered name.
    """

    consistent = derivative_state is not None and _has_consistent_derivative_operations(
        mol, ast, specs, numbering, indicated_hydrogens, derivative_state
    )
    atom_by_locant = {locant: atom for atom, locant in numbering.input_locant_maps[0]}
    intrinsic_carbon_composition = consistent and any(
        mol.atoms[atom_by_locant[locant]].symbol == "C" for locant in indicated_hydrogens
    )
    if (
        specs
        and all(spec.template.family == "generated_hw_monocycle" for spec in specs.values())
        and not intrinsic_carbon_composition
    ):
        return ("fusion of exclusively generated Hantzsch-Widman components lacks an audited orientation anchor",)
    if derivative_state is None or consistent:
        return ()
    if _has_complete_hydrogenation(mol, numbering, indicated_hydrogens, derivative_state):
        return ()
    if indicated_hydrogens and (
        derivative_state.hydro_operations
        or derivative_state.unsaturation_operations
        or derivative_state.external_pi_operations
    ):
        return ("combined indicated-hydrogen and bond/oxo derivative fusion grammar is not audited",)
    return ("combined fusion derivative operations lack independent applicable atom scopes",)


def _has_consistent_derivative_operations(
    mol: Molecule,
    ast: FusionNameAst,
    specs: Mapping[int, FusionComponentSpec],
    numbering: FusionNumberingProof,
    indicated_hydrogens: tuple[SystemLocant, ...],
    state: ParentDerivativeState,
) -> bool:
    """Check chemical operation scopes; independent replay proves their contents.

    Carbon operations belong to the completed graph, irrespective of component
    boundaries. Non-aromatic N-H can consume missing pi valence, so multiple
    such sites still require the separate complete-hydrogenation proof.
    """
    atom_by_locant = {locant: atom for atom, locant in numbering.input_locant_maps[0]}
    atoms = frozenset(atom_by_locant.values())
    for operation in state.imino_operations + state.alkylidene_operations:
        parent, external = operation.parent_atom_id, operation.external_atom_id
        if (
            parent not in atoms
            or external not in mol.atoms
            or external in atoms
            or mol.atoms[external].symbol != operation.external_atom_symbol
            or not is_neutral_external_pi_ligand(mol, parent, external)
            or mol.get_bond(parent, external).idx != operation.bond_id
            or not any(
                atom == parent and str(locant) == operation.locant for atom, locant in numbering.input_locant_maps[0]
            )
        ):
            return False
    if (
        state.bond_delta.hydrogenated_edges
        and not state.hydro_operations
        and (state.pi_redistribution is None or state.pi_redistribution.hydrogenated_atom_ids)
    ):
        return False
    if any(locant not in atom_by_locant for locant in indicated_hydrogens):
        return False
    h_atoms = {atom_by_locant[locant] for locant in indicated_hydrogens}
    hydro = {atom for operation in state.hydro_operations for atom in operation.atom_ids}
    oxo = {operation.parent_atom_id for operation in state.external_pi_operations}
    added = {atom for operation in state.added_hydrogen_operations for atom in operation.atom_ids}
    intrinsic = {atom for operation in state.intrinsic_hydro_operations for atom in operation.atom_ids}
    unsaturated = {atom for operation in state.unsaturation_operations for atom in operation.atom_ids}
    if not (h_atoms | hydro | oxo | added | intrinsic | unsaturated) <= atoms:
        return False
    if not (hydro or oxo or added or intrinsic or unsaturated) and all(
        mol.atoms[atom].symbol != "C" for atom in h_atoms
    ):
        return True
    if h_atoms & (hydro | oxo | added | intrinsic) or hydro & (oxo | added | intrinsic) or added & (oxo | intrinsic):
        return False
    if any(mol.atoms[atom].symbol != "C" for atom in intrinsic):
        return False
    neutral_nh_witnesses = {
        atom
        for atom in h_atoms | added
        if mol.atoms[atom].symbol == "N"
        and not mol.atoms[atom].charge
        and mol.atoms[atom].total_h_count == 1
        and len(neighbors := mol.get_neighbors(atom)) == 2
        and all(neighbor in atoms and mol.get_bond(atom, neighbor).order == 1 for neighbor in neighbors)
        and all(order == 1 for edge, order in state.bond_delta.assignment.orders if atom in edge)
    }
    added_n_witnesses = {
        atom
        for atom in added
        if is_added_hydrogen_nitrogen(mol, atoms, atom)
        and all(order == 1 for edge, order in state.bond_delta.assignment.orders if atom in edge)
    }
    if any(mol.atoms[atom].symbol != "C" and atom not in added_n_witnesses for atom in added):
        return False
    for atom in hydro:
        value = mol.atoms[atom]
        if value.symbol == "C":
            continue
        neighbors = mol.get_neighbors(atom)
        if (
            value.symbol != "N"
            or value.charge
            or value.is_aromatic
            or any(mol.get_bond(atom, other).order != 1 for other in neighbors)
            or value.total_h_count + len(neighbors) != 3
        ):
            return False
    if any(mol.atoms[atom].charge for atom in added | intrinsic):
        return False
    # Mixed extra unsaturation and hydrogen operations need a redistribution
    # proof; replay represents a proved redistribution without raw unsaturation.
    if state.unsaturation_operations and (h_atoms or hydro or oxo or added or intrinsic):
        return False
    carbon_h = {atom for atom in h_atoms if mol.atoms[atom].symbol == "C"}
    nitrogen_h = h_atoms - carbon_h
    if any(mol.atoms[atom].symbol != "N" for atom in nitrogen_h):
        return False
    # Neutral nonaromatic citations must retain a single-bond donor witness.
    # Charged nitrogen has its separate charge-operation reconstruction.
    if any(
        atom not in neutral_nh_witnesses
        for atom in nitrogen_h
        if not mol.atoms[atom].is_aromatic and not mol.atoms[atom].charge
    ):
        return False
    if carbon_h:
        # Neutral N-H must retain its observed single-bond valence. The
        # completed carbon witness is independently replayed below.
        if added or intrinsic or not nitrogen_h <= neutral_nh_witnesses:
            return False
        if not carbon_h <= intrinsic_carbon_candidate_atoms(ast, specs, mol):
            return False
        if not all(is_intrinsic_carbon_h_site(mol, atom, atoms) for atom in carbon_h):
            return False
        if any(order != 1 for edge, order in state.bond_delta.assignment.orders if carbon_h.intersection(edge)):
            return False
        if oxo:
            donor_graph = component_parent_graph(ast, specs, relocate_carbon_h=True)
            donors = intrinsic_parent_lone_pair_sites(mol, donor_graph)
            if not _has_carbon_h_oxo_bond_consumption(mol, atoms, state, intrinsic_donors=donors):
                return False
    represented_external = {operation.bond_id for operation in state.external_pi_operations}
    unrepresented_external = [
        (atom, neighbor)
        for atom in atoms
        for neighbor in mol.get_neighbors(atom)
        if neighbor not in atoms
        and mol.get_bond(atom, neighbor).order > 1
        and mol.get_bond(atom, neighbor).idx not in represented_external
    ]
    if not unrepresented_external:
        return True
    # External suffix chemistry is separate from the parent operations. Admit
    # it only with nonempty, disjoint ordinary hydro already checked
    # above; independent replay still verifies every atom, bond and locant.
    if not hydro or h_atoms or added or intrinsic or unsaturated:
        return False
    return all(
        mol.atoms[atom].symbol == "C"
        and not mol.atoms[atom].charge
        and atom not in hydro | oxo
        and mol.get_bond(atom, neighbor).order == 2
        and mol.atoms[neighbor].symbol in {"C", "N"}
        and not mol.atoms[neighbor].charge
        and mol.atoms[neighbor].total_h_count
        + sum(mol.get_bond(neighbor, other).order for other in mol.get_neighbors(neighbor))
        == mol.atoms[neighbor].element.standard_valence
        for atom, neighbor in unrepresented_external
    )


def _has_carbon_h_oxo_bond_consumption(
    mol: Molecule,
    atoms: frozenset[int],
    state: ParentDerivativeState,
    *,
    intrinsic_donors: frozenset[int] = frozenset(),
) -> bool:
    """Prove carbon-H/oxo composition without counting oxo-consumed pi as hydro.

    A carbonyl replaces the parent double bond at its carbon; the other end
    must be an independent CH2 site (possibly bearing single-bond branches).
    A neutral lambda-oxo spectator instead preserves both skeletal single
    bonds and requires complete, graph-bound oxo ligand ownership.
    The indicated-H model and derivative replay establish the remaining sites.
    """

    from .external_pi_consumption import has_paired_external_pi_consumption

    if has_paired_external_pi_consumption(mol, atoms, state):
        return True
    for operation in state.external_pi_operations:
        atom = operation.parent_atom_id
        if neutral_lambda_oxo_bonding_number(mol, atom) is not None:
            neighbors = atoms.intersection(mol.get_neighbors(atom))
            expected = dict(state.bond_delta.assignment.orders)
            if (
                operation not in state.oxo_operations
                or len(neighbors) != mol.atoms[atom].element.standard_valence
                or any(
                    expected.get(normalize_edge(atom, other)) != 1 or mol.get_bond(atom, other).order != 1
                    for other in neighbors
                )
            ):
                return False
            actual_oxo = {
                mol.get_bond(atom, other).idx: other
                for other in mol.get_neighbors(atom)
                if other not in atoms and mol.get_bond(atom, other).order == 2
            }
            cited_oxo = tuple(
                (item.bond_id, item.oxygen_atom_id) for item in state.oxo_operations if item.parent_atom_id == atom
            )
            if len(cited_oxo) != len(actual_oxo) or dict(cited_oxo) != actual_oxo:
                return False
            continue
        if (
            mol.atoms[atom].symbol != "C"
            or mol.atoms[atom].charge
            or len(atoms.intersection(mol.get_neighbors(atom))) != 2
            or any(mol.get_bond(atom, other).order != 1 for other in mol.get_neighbors(atom) if other in atoms)
        ):
            return False
        consumed = [edge for edge, order in state.bond_delta.assignment.orders if order == 2 and atom in edge]
        if not consumed and intrinsic_donors.intersection(mol.get_neighbors(atom)):
            # Intrinsic donor composition already makes both skeletal bonds
            # single. The independently replayed external pi operation owns
            # this carbon valence without inventing another carbon-H citation.
            continue
        if len(consumed) != 1:
            return False
        other = next(site for site in consumed[0] if site != atom)
        if not is_intrinsic_carbon_h_site(mol, other, atoms):
            return False
    return bool(state.external_pi_operations)


def _has_complete_hydrogenation(
    mol: Molecule,
    numbering: FusionNumberingProof,
    indicated_hydrogens: tuple[SystemLocant, ...],
    state: ParentDerivativeState,
) -> bool:
    """Complete hydrogenation belongs to the whole parent, not one component.

    Fusion nitrogen and proved saturated N-H sites are single in the model.
    Only the remaining parent double bonds contribute hydrogenation pairs;
    the derivative audit independently checks their exact locants and bonds.
    """

    if state.unsaturation_operations or state.external_pi_operations or not state.hydro_operations:
        return False
    atom_by_locant = {locant: atom for atom, locant in numbering.input_locant_maps[0]}
    atoms = frozenset(atom_by_locant.values())
    hydrogenated = frozenset(state.bond_delta.hydrogenated_edges)
    if indicated_hydrogens:
        sites = saturated_nitrogen_hydrogen_sites(
            mol, atoms, {atom_by_locant.get(locant) for locant in indicated_hydrogens}
        )
        if not sites or any(mol.atoms[atom].symbol == "N" and atom not in sites for atom in atoms):
            return False
        covered = {atom for edge in hydrogenated for atom in edge}
        # An odd-atom mancude parent can have one residual carbon H site.
        # Additional uncovered positions need explicit typed H operations.
        if len(covered) != 2 * len(hydrogenated) or len(atoms - sites - covered) > 1 or sites & covered:
            return False
        if any(order != 1 for edge, order in state.bond_delta.assignment.orders if sites.intersection(edge)):
            return False
    elif not has_complete_saturated_hydrogenation(mol, atoms, state) and not all(
        mol.atoms[atom].charge == 0 and mol.atoms[atom].symbol in {"C", "N", "O", "S"} for atom in atoms
    ):
        return False
    return (
        not any(
            neighbor not in atoms and mol.get_bond(atom, neighbor).order > 1
            for atom in atoms
            for neighbor in mol.get_neighbors(atom)
        )
        and all(mol.get_bond(*edge).order == 1 for edge, _ in state.bond_delta.assignment.orders)
        and all(
            set(edge) <= atoms and (order != 2 or edge in hydrogenated)
            for edge, order in state.bond_delta.assignment.orders
        )
    )


def _reconstruct(
    ast: FusionNameAst,
    specs: Mapping[int, FusionComponentSpec],
    mol: Molecule,
    errors: list[str],
) -> _ReconstructedGraph:
    matches = {match.occurrence_id: match for match in ast.component_occurrences}
    nodes: list[_Node] = []
    labels: dict[_Node, tuple[str, int]] = {}
    input_by_node: dict[_Node, int] = {}
    skeleton_by_node: dict[_Node, int] = {}
    local_edges: list[tuple[_Node, _Node, str]] = []
    input_edges_by_occurrence: dict[int, frozenset[_Edge]] = {}

    for occurrence, match in matches.items():
        spec = specs[occurrence]
        input_map = match.input_atom_by_locant
        skeleton_map = match.skeleton_atom_by_locant
        if set(input_map) != set(spec.locants) or set(skeleton_map) != set(spec.locants):
            errors.append(f"component occurrence {occurrence} does not map every spec locant exactly once")
            continue
        atom_by_locant = {atom.locant: atom for atom in spec.atoms}
        for locant in spec.locants:
            node = (occurrence, locant)
            nodes.append(node)
            atom = atom_by_locant[locant]
            labels[node] = (atom.symbol, atom.charge)
            input_by_node[node] = input_map[locant]
            skeleton_by_node[node] = skeleton_map[locant]
        occurrence_edges: set[_Edge] = set()
        for bond in spec.bonds:
            left, right = bond.locants
            local_edges.append(((occurrence, left), (occurrence, right), bond.bond_class))
            occurrence_edges.add(normalize_edge(input_map[left], input_map[right]))
        input_edges_by_occurrence[occurrence] = frozenset(occurrence_edges)

    disjoint = _DisjointSet(nodes)
    for join in ast.joins:
        if join.attached_occurrence not in matches or join.host_occurrence not in matches:
            errors.append("fusion join references an unknown component occurrence")
            continue
        attached_nodes = tuple((join.attached_occurrence, locant.text) for locant in join.interface.attached_path)
        host_nodes = tuple((join.host_occurrence, locant.text) for locant in join.interface.host_path)
        attached_input = tuple(input_by_node.get(node) for node in attached_nodes)
        host_input = tuple(input_by_node.get(node) for node in host_nodes)
        if attached_input != join.interface.ordered_input_atoms:
            errors.append(
                f"join {join.attached_occurrence}->{join.host_occurrence} attached path disagrees "
                "with its ordered input atoms"
            )
            continue
        if host_input != join.interface.ordered_input_atoms:
            errors.append(
                f"join {join.attached_occurrence}->{join.host_occurrence} host path disagrees "
                "with its ordered input atoms"
            )
            continue
        for attached, host in zip(attached_nodes, host_nodes, strict=True):
            disjoint.union(attached, host)

    classes: dict[_Node, list[_Node]] = defaultdict(list)
    for node in nodes:
        classes[disjoint.find(node)].append(node)

    reconstructed_input_atoms: dict[int, tuple[str, int]] = {}
    reconstructed_skeleton_atoms: dict[int, tuple[str, int]] = {}
    root_input: dict[_Node, int] = {}
    root_skeleton: dict[_Node, int] = {}
    for root, members in classes.items():
        member_labels = {labels[node] for node in members}
        input_ids = {input_by_node[node] for node in members}
        skeleton_ids = {skeleton_by_node[node] for node in members}
        if len(member_labels) != 1:
            errors.append(f"merged component atoms have incompatible element or charge definitions: {members}")
            continue
        if len(input_ids) != 1:
            errors.append(f"merged component atoms map to different input atoms: {members}")
            continue
        if len(skeleton_ids) != 1:
            errors.append(f"merged component atoms map to different abstract atoms: {members}")
            continue
        label = next(iter(member_labels))
        input_id = next(iter(input_ids))
        skeleton_id = next(iter(skeleton_ids))
        if input_id in reconstructed_input_atoms and reconstructed_input_atoms[input_id] != label:
            errors.append(f"input atom {input_id} receives incompatible component definitions")
        if skeleton_id in reconstructed_skeleton_atoms and reconstructed_skeleton_atoms[skeleton_id] != label:
            errors.append(f"abstract atom {skeleton_id} receives incompatible component definitions")
        reconstructed_input_atoms[input_id] = label
        reconstructed_skeleton_atoms[skeleton_id] = label
        root_input[root] = input_id
        root_skeleton[root] = skeleton_id

    input_edges: set[_Edge] = set()
    skeleton_edges: dict[_Edge, str] = {}
    for left, right, bond_class in local_edges:
        left_root = disjoint.find(left)
        right_root = disjoint.find(right)
        if left_root == right_root:
            errors.append(f"fusion collapse creates a self bond from {left} to {right}")
            continue
        if left_root not in root_input or right_root not in root_input:
            continue
        input_edge = normalize_edge(root_input[left_root], root_input[right_root])
        skeleton_edge = normalize_edge(root_skeleton[left_root], root_skeleton[right_root])
        input_edges.add(input_edge)
        previous = skeleton_edges.get(skeleton_edge)
        if previous is None:
            skeleton_edges[skeleton_edge] = bond_class
        else:
            merged = merge_parent_bond_classes(previous, bond_class)
            if merged is None:
                errors.append(f"shared abstract edge {skeleton_edge} has incompatible bond classes")
            else:
                skeleton_edges[skeleton_edge] = merged

    return _ReconstructedGraph(
        input_atom_by_node=input_by_node,
        skeleton_atom_by_node=skeleton_by_node,
        input_edges_by_occurrence=input_edges_by_occurrence,
        input_atoms=reconstructed_input_atoms,
        input_edges=frozenset(input_edges),
        skeleton_atoms=reconstructed_skeleton_atoms,
        skeleton_edges=skeleton_edges,
    )


def _host_path_from_sides(
    join: FusionJoin,
    host: FusionComponentSpec,
    errors: list[str],
) -> tuple[ComponentLocant, ...]:
    occurrence = join.host_occurrence
    if join.host_locants:
        return join.host_locants

    side_indices: list[int] = []
    for side in join.host_sides:
        for letter in side.letter:
            index = ord(letter) - ord("a")
            if not 0 <= index < len(host.peripheral_order):
                errors.append(f"host side {letter!r} is not defined by component {host.key}")
                return ()
            side_indices.append(index)
    edges = [
        (
            host.peripheral_order[index],
            host.peripheral_order[(index + 1) % len(host.peripheral_order)],
        )
        for index in side_indices
    ]
    path = _ordered_side_path(edges)
    if not path:
        errors.append(f"host sides do not form one ordered interface on component {host.key}")
        return ()
    prime_depths = {side.prime_depth for side in join.host_sides}
    if len(prime_depths) != 1:
        errors.append(f"host sides use inconsistent prime depths on component {host.key}")
        return ()
    prime_depth = next(iter(prime_depths))
    return tuple(ComponentLocant(occurrence, locant, prime_depth) for locant in path)


def _ordered_side_path(edges: list[tuple[str, str]]) -> tuple[str, ...]:
    if not edges:
        return ()
    path = [edges[0][0], edges[0][1]]
    for left, right in edges[1:]:
        if path[-1] != left:
            return ()
        path.append(right)
    return tuple(path)


def _audit_component_and_face_coverage(
    mol: Molecule,
    parent_atoms: frozenset[int],
    ast: FusionNameAst,
    specs: Mapping[int, FusionComponentSpec],
    numbering: FusionNumberingProof,
    reconstruction: _ReconstructedGraph,
    errors: list[str],
) -> None:
    matches = {match.occurrence_id: match for match in ast.component_occurrences}
    scopes = []
    face_owners: Counter[int] = Counter()
    faces = {face.id: face for face in numbering.selected_face_model.faces}
    for occurrence, match in matches.items():
        input_map = match.input_atom_by_locant
        spec = specs[occurrence]
        atom_ids = set(input_map.values())
        edges = {
            normalize_edge(input_map[bond.locants[0]], input_map[bond.locants[1]])
            for bond in spec.bonds
            if set(bond.locants) <= input_map.keys()
        }
        scopes.append(component_scope(occurrence, atom_ids, edges))
        face_owners.update(match.covered_face_ids)
        unknown_faces = match.covered_face_ids - faces.keys()
        if unknown_faces:
            errors.append(f"component occurrence {occurrence} covers unknown faces: {sorted(unknown_faces)}")
            continue
        mapped_rings = {
            frozenset(input_map[locant] for locant in ring) for ring in spec.rings if set(ring) <= input_map.keys()
        }
        selected_rings = {frozenset(faces[face_id].atom_cycle) for face_id in match.covered_face_ids}
        if mapped_rings != selected_rings:
            errors.append(f"component occurrence {occurrence} does not reconstruct its declared faces")

    expected_face_ids = set(faces)
    if set(face_owners) != expected_face_ids or any(count != 1 for count in face_owners.values()):
        errors.append("component occurrences do not cover every selected face exactly once")

    target_edges = frozenset(edges_within_atoms(mol, set(parent_atoms)))
    cover = audit_component_cover(scopes, target_atom_ids=parent_atoms, target_edges=target_edges)
    errors.extend(cover.errors)
    if reconstruction.input_edges != target_edges:
        errors.append("component reconstruction does not exactly cover selected parent edges")


def _audit_descriptors(
    mol: Molecule,
    ast: FusionNameAst,
    specs: Mapping[int, FusionComponentSpec],
    reconstruction: _ReconstructedGraph,
    numbering: FusionNumberingProof,
    errors: list[str],
) -> None:
    matches = {match.occurrence_id: match for match in ast.component_occurrences}
    joins_by_pair: dict[frozenset[int], FusionJoin] = {}
    for index, join in enumerate(ast.joins):
        pair = frozenset((join.attached_occurrence, join.host_occurrence))
        if pair in joins_by_pair:
            errors.append(f"component pair {sorted(pair)} has more than one fusion join")
        joins_by_pair[pair] = join

        attached = matches[join.attached_occurrence]
        host = matches[join.host_occurrence]
        attached_map = attached.input_atom_by_locant
        host_map = host.input_atom_by_locant
        evidence = join.interface
        attached_path = tuple(attached_map.get(locant.text) for locant in evidence.attached_path)
        host_path = tuple(host_map.get(locant.text) for locant in evidence.host_path)
        if attached_path != evidence.ordered_input_atoms or host_path != evidence.ordered_input_atoms:
            errors.append(
                f"join {join.attached_occurrence}->{join.host_occurrence} component paths do not preserve "
                "the ordered input interface"
            )
            continue
        derived_ordered_edges = tuple(
            normalize_edge(left, right) for left, right in zip(attached_path, attached_path[1:])
        )
        derived_edges = frozenset(derived_ordered_edges)
        actual_edges = (
            reconstruction.input_edges_by_occurrence[join.attached_occurrence]
            & reconstruction.input_edges_by_occurrence[join.host_occurrence]
        )
        derived_atoms = frozenset(attached_path)
        if evidence.ordered_input_edges != derived_ordered_edges:
            errors.append(f"join {join.attached_occurrence}->{join.host_occurrence} stores a wrong ordered edge path")
        if derived_edges != actual_edges:
            errors.append(
                f"join {join.attached_occurrence}->{join.host_occurrence} does not cite every and only shared edge"
            )
        if derived_atoms != frozenset(atom for edge in actual_edges for atom in edge):
            errors.append(f"join {join.attached_occurrence}->{join.host_occurrence} cites wrong shared atoms")
        expected_bond_ids = frozenset(bond.idx for edge in actual_edges if (bond := mol.get_bond(*edge)) is not None)
        if evidence.shared_input_atoms != derived_atoms:
            errors.append(f"join {join.attached_occurrence}->{join.host_occurrence} stores wrong shared atoms")
        if evidence.shared_input_bonds != expected_bond_ids:
            errors.append(f"join {join.attached_occurrence}->{join.host_occurrence} stores wrong shared bonds")
        if not evidence.shared_input_bonds <= numbering.selected_face_model.fusion_edges:
            errors.append(
                f"join {join.attached_occurrence}->{join.host_occurrence} is not a selected-layout fusion interface"
            )
        expected_host_path = _host_path_from_sides(join, specs[join.host_occurrence], errors)
        if expected_host_path and expected_host_path != evidence.host_path:
            errors.append(
                f"join {join.attached_occurrence}->{join.host_occurrence} host sides disagree with its typed host path"
            )
        if evidence.host_locants:
            expected_kind = FusionJoinKind.HIGHER_ORDER
        else:
            expected_kind = FusionJoinKind.ORTHO if len(derived_ordered_edges) == 1 else FusionJoinKind.ORTHO_PERI
        if evidence.kind is not expected_kind:
            errors.append(
                f"join {join.attached_occurrence}->{join.host_occurrence} has the wrong fusion kind "
                "for its ordered interface"
            )

        if ast.descriptors:
            descriptor = ast.descriptors[index]
            if not _descriptor_matches_join(descriptor, join):
                errors.append(f"descriptor {index} does not preserve its fusion join")

    occurrences = sorted(matches)
    for position, left in enumerate(occurrences):
        for right in occurrences[position + 1 :]:
            overlap = reconstruction.input_edges_by_occurrence[left] & reconstruction.input_edges_by_occurrence[right]
            if bool(overlap) != (frozenset((left, right)) in joins_by_pair):
                errors.append(
                    f"shared interface between component occurrences {left} and {right} is not described exactly once"
                )

    citation = _citation_plan(ast)
    primary_joins = tuple(ast.joins[index] for index in citation.primary_join_indices)
    children_by_host: dict[int, list[int]] = defaultdict(list)
    joins_by_attached: dict[int, FusionJoin] = {}
    for join in primary_joins:
        children_by_host[join.host_occurrence].append(join.attached_occurrence)
        joins_by_attached[join.attached_occurrence] = join
    nonleaves = set(children_by_host)
    expected_groups = []
    multiplicity_offsets: dict[int, int] = {}
    audit_multiplicity = ast.plan_kind == "multiplicative_tree" or bool(ast.multiplicative_groups)
    for _host, children in sorted(children_by_host.items()):
        by_identity: dict[tuple, list[int]] = defaultdict(list)
        for child in children:
            if child in nonleaves:
                continue
            join = joins_by_attached[child]
            by_identity[multiplicative_attachment_key(specs[child], join)].append(child)
        for members in by_identity.values():
            if len(members) < 2:
                continue
            ordered = tuple(
                sorted(members, key=lambda child: multiplicative_member_order_key(joins_by_attached[child]))
            )
            try:
                multiplier = multipliers.basic(len(ordered))
            except KeyError:
                continue
            if audit_multiplicity:
                expected_groups.append((ordered, multiplier))
                for prime_depth, occurrence in enumerate(ordered):
                    multiplicity_offsets[occurrence] = prime_depth
                    prime_depth += joins_by_attached[occurrence].order - 1
                    depths = {locant.prime_depth for locant in joins_by_attached[occurrence].interface.attached_path}
                    if depths != {prime_depth}:
                        errors.append(
                            f"multiplicative occurrence {occurrence} has prime depth {depths}, expected {prime_depth}"
                        )
    actual_groups = sorted((group.occurrence_ids, group.multiplier) for group in ast.multiplicative_groups)
    if audit_multiplicity and actual_groups != sorted(expected_groups):
        errors.append("multiplicative groups do not match exact sibling interface orbits")

    closing = set(citation.cycle_closing_join_indices)
    if any(ast.joins[index].kind is not FusionJoinKind.HIGHER_ORDER for index in closing):
        errors.append("citation-plan join classes disagree with descriptor kinds")

    expected_primary: dict[int, tuple[int, int]] = {}

    def collect_primary_orders(node: FusionCitationNode, depth: int) -> None:
        for child in node.children:
            expected_primary[child.occurrence_id] = (node.occurrence_id, depth + 1)
            collect_primary_orders(child, depth + 1)

    for root in citation.roots:
        collect_primary_orders(root, 0)
    for index in citation.primary_join_indices:
        join = ast.joins[index]
        expected = expected_primary.get(join.attached_occurrence)
        if expected is None:
            errors.append(f"primary join {index} is absent from the citation tree")
            continue
        expected_host, expected_order = expected
        if join.host_occurrence != expected_host or join.order != expected_order:
            errors.append(f"primary join {index} disagrees with its citation-tree order")
        if expected_order == 1:
            if join.kind is FusionJoinKind.HIGHER_ORDER:
                errors.append(f"first-order primary join {index} incorrectly uses numeric host locants")
            continue
        if join.kind is not FusionJoinKind.HIGHER_ORDER:
            errors.append(f"higher-order primary join {index} lacks numeric host locants")
            continue
        attached_depths = {locant.prime_depth for locant in join.attached_locants}
        host_depths = {locant.prime_depth for locant in join.host_locants}
        if attached_depths != {
            expected_order - 1 + multiplicity_offsets.get(join.attached_occurrence, 0)
        } or host_depths != {expected_order - 2}:
            errors.append(f"higher-order primary join {index} has incorrect intermediate-component prime depths")

    if any(ast.joins[index].kind is FusionJoinKind.HIGHER_ORDER for index in citation.interparent_join_indices):
        errors.append("interparent joins must retain parent-side descriptors")
    interparents = set(citation.interparent_occurrences)
    parent_set = set(citation.parent_occurrences)
    for occurrence in interparents:
        joined_hosts = {join.host_occurrence for join in ast.joins if join.attached_occurrence == occurrence}
        if len(joined_hosts & parent_set) < 2:
            errors.append(f"interparent component occurrence {occurrence} does not join multiple parents")


def _descriptor_matches_join(descriptor: FusionDescriptor, join: FusionJoin) -> bool:
    return descriptor == FusionDescriptor.from_interface(join.interface)


def _audit_reconstructed_graph(
    mol: Molecule,
    parent_atoms: frozenset[int],
    abstract: FusionGraph,
    reconstructed: _ReconstructedGraph,
    charge_operations: tuple[FusionChargeOperation, ...],
    errors: list[str],
) -> None:
    actual_labels = {atom: (mol.atoms[atom].symbol, mol.atoms[atom].charge) for atom in parent_atoms}
    reconstructed_observed = dict(reconstructed.input_atoms)
    for operation in charge_operations:
        symbol, base_charge = reconstructed_observed.get(operation.atom_id, ("", 0))
        if symbol == operation.symbol and base_charge == operation.base_charge:
            reconstructed_observed[operation.atom_id] = (symbol, operation.observed_charge)
    if reconstructed_observed != actual_labels:
        errors.append("reconstructed component atoms differ from selected input elements or formal charges")
    actual_edges = frozenset(edges_within_atoms(mol, set(parent_atoms)))
    if reconstructed.input_edges != actual_edges:
        errors.append("reconstructed component connectivity differs from the selected input parent")

    abstract_labels = {atom.id: (atom.symbol, atom.formal_charge) for atom in abstract.atoms}
    abstract_edges = {normalize_edge(*bond.atoms): bond.bond_class for bond in abstract.bonds}
    if reconstructed.skeleton_atoms != abstract_labels:
        errors.append("reconstructed component atoms differ from the declared abstract parent graph")
    if reconstructed.skeleton_edges != abstract_edges:
        errors.append("reconstructed component bonds differ from the declared abstract parent graph")


def _audit_component_pi_constraints(
    ast: FusionNameAst,
    specs: Mapping[int, FusionComponentSpec],
    abstract: FusionGraph,
    errors: list[str],
) -> None:
    expected = defaultdict(list)
    relocate_carbon_h = component_carbon_h_relocation_scope(ast, specs)
    for match in ast.component_occurrences:
        spec = specs[match.occurrence_id]
        for atom in component_parent_atoms(spec) if relocate_carbon_h else spec.atoms:
            expected[match.input_atom_by_locant[atom.locant]].append(atom)
    for atom in abstract.atoms:
        components = expected[atom.id]
        if (
            atom.pi_capacity != min(site.resolved_pi_capacity for site in components)
            or atom.forced_single != any(site.forced_single for site in components)
            or atom.saturated != any(site.saturated for site in components)
        ):
            errors.append("abstract parent changes a component's fixed pi-capacity or saturation constraint")


def _audit_numbering(
    mol: Molecule,
    parent_atoms: frozenset[int],
    abstract: FusionGraph,
    numbering: FusionNumberingProof,
    charge_operations: tuple[FusionChargeOperation, ...],
    errors: list[str],
    *,
    ast: FusionNameAst | None = None,
) -> None:
    abstract_map = dict(numbering.abstract_atom_to_locant)
    abstract_labels = {atom.id: (atom.symbol, atom.formal_charge) for atom in abstract.atoms}
    abstract_edges = frozenset(normalize_edge(*bond.atoms) for bond in abstract.bonds)
    if set(abstract_map) != set(abstract_labels) or len(set(abstract_map.values())) != len(abstract_map):
        errors.append("completed abstract numbering is not a bijection over the parent graph")

    _audit_face_model(mol, parent_atoms, numbering, errors)
    _audit_layout_numbering_compatibility(parent_atoms, numbering, errors, ast=ast)
    face_membership = Counter(atom for face in numbering.selected_face_model.faces for atom in face.atom_cycle)
    fusion_atoms = {atom for atom, count in face_membership.items() if count > 1}

    operation_by_atom = {operation.atom_id: operation for operation in charge_operations}
    for input_map_items in numbering.input_locant_maps:
        input_map = dict(input_map_items)
        if set(input_map) != parent_atoms or len(set(input_map.values())) != len(input_map):
            errors.append("completed input numbering is not a bijection over the selected parent")
            continue
        abstract_by_locant = {locant: atom for atom, locant in abstract_map.items()}
        input_to_abstract = {atom: abstract_by_locant.get(locant) for atom, locant in input_map.items()}
        if any(atom is None for atom in input_to_abstract.values()):
            errors.append("input numbering uses locants absent from the abstract numbering")
            continue
        for input_atom, abstract_atom in input_to_abstract.items():
            assert abstract_atom is not None
            expected_symbol, expected_charge = abstract_labels[abstract_atom]
            operation = operation_by_atom.get(input_atom)
            if operation is not None:
                expected_charge = operation.observed_charge
            if (mol.atoms[input_atom].symbol, mol.atoms[input_atom].charge) != (expected_symbol, expected_charge):
                errors.append("input locant map does not preserve element and formal-charge labels")
                break
        mapped_edges = frozenset(
            normalize_edge(input_to_abstract[left], input_to_abstract[right])
            for left, right in edges_within_atoms(mol, set(parent_atoms))
        )
        if mapped_edges != abstract_edges:
            errors.append("input locant map is not graph preserving")

        for atom, locant in input_map.items():
            if locant.interior_distance is not None:
                continue
            is_fusion_carbon = atom in fusion_atoms and mol.atoms[atom].symbol == "C"
            if is_fusion_carbon != bool(locant.fusion_suffix):
                errors.append("fusion-carbon suffix locants do not match the selected face model")
                break
            if atom in fusion_atoms and mol.atoms[atom].symbol != "C" and locant.fusion_suffix:
                errors.append("fusion heteroatoms must receive integer completed-system locants")
                break


def _audit_layout_numbering_compatibility(
    parent_atoms: frozenset[int],
    numbering: FusionNumberingProof,
    errors: list[str],
    *,
    ast: FusionNameAst | None = None,
) -> None:
    """Verify that the selected layout yields the stored completed numbering."""

    layout = numbering.selected_layout
    if not layout.atom_positions:
        # Synthetic audit fixtures predating geometric numbering remain valid;
        # production plans always carry complete positioned layouts.
        return
    atom_positions = {atom: (x, y) for atom, x, y in layout.atom_positions}
    face_positions = {face: (x, y) for face, x, y in layout.face_positions}
    face_ids = {face.id for face in numbering.selected_face_model.faces}
    if set(atom_positions) != parent_atoms:
        errors.append("selected layout does not position every and only parent atom")
        return
    if set(face_positions) != face_ids:
        errors.append("selected layout does not position every and only selected face")
    if len(set(atom_positions.values())) != len(atom_positions):
        errors.append("selected layout assigns the same position to multiple parent atoms")

    needs_entry = any(shape in _DIRECTED_SHAPE_IDS for _, shape in layout.face_shapes)
    entry = layout.component_entry_edge
    if needs_entry and entry is None:
        errors.append("directed layout is missing its component entry")
    if entry is not None:
        left, right = (atom_positions[atom] for atom in entry)
        if left[1] != right[1] or left[0] <= right[0]:
            errors.append("component entry direction is incompatible with the layout orientation")
        ownership = sum(
            frozenset(entry)
            in {frozenset(pair) for pair in zip(face.atom_cycle, face.atom_cycle[1:] + face.atom_cycle[:1])}
            for face in numbering.selected_face_model.faces
        )
        if ownership != 2:
            errors.append("component entry is not a shared fusion edge")
        if ast is not None and entry not in {join.interface.ordered_input_atoms for join in ast.joins}:
            errors.append("component entry does not match an ordered fusion interface")

    boundary = numbering.selected_face_model.outer_boundary
    signed_area = sum(
        atom_positions[left][0] * atom_positions[right][1] - atom_positions[right][0] * atom_positions[left][1]
        for left, right in zip(boundary, boundary[1:] + boundary[:1])
    )
    if signed_area == 0:
        errors.append("selected layout has a degenerate outer boundary")
        return
    clockwise = boundary if signed_area < 0 else tuple(reversed(boundary))
    locant_map = dict(numbering.abstract_atom_to_locant)
    if set(locant_map) != parent_atoms:
        return
    peripheral_atoms = set(boundary)
    expected = tuple(sorted(peripheral_atoms, key=lambda atom: _system_locant_key(locant_map[atom])))
    start = clockwise.index(expected[0])
    geometric_order = clockwise[start:] + clockwise[:start]
    if geometric_order != expected:
        errors.append("completed locant order is incompatible with the selected layout perimeter")


def _system_locant_key(locant) -> tuple[int, str, int]:
    return locant.base, locant.fusion_suffix, locant.interior_distance or 0


def _audit_face_model(
    mol: Molecule,
    parent_atoms: frozenset[int],
    numbering: FusionNumberingProof,
    errors: list[str],
) -> None:
    model = numbering.selected_face_model
    owners: dict[int, list[int]] = defaultdict(list)
    reconstructed_edges: set[int] = set()
    for face in model.faces:
        if not set(face.atom_cycle) <= parent_atoms:
            errors.append(f"numbering face {face.id} contains atoms outside the selected parent")
            continue
        expected_ids = []
        for left, right in zip(face.atom_cycle, face.atom_cycle[1:] + face.atom_cycle[:1]):
            bond = mol.get_bond(left, right)
            if bond is None:
                errors.append(f"numbering face {face.id} contains a nonexistent input edge")
                continue
            expected_ids.append(bond.idx)
            owners[bond.idx].append(face.id)
            reconstructed_edges.add(bond.idx)
        if tuple(expected_ids) != face.edge_cycle:
            errors.append(f"numbering face {face.id} edge cycle does not follow its atom cycle")

    expected_parent_edges = {
        bond.idx for bond in mol.bonds.values() if bond.u in parent_atoms and bond.v in parent_atoms
    }
    if reconstructed_edges != expected_parent_edges:
        errors.append("numbering face model does not reconstruct every selected parent edge")
    expected_owners = tuple(sorted((edge, tuple(sorted(face_ids))) for edge, face_ids in owners.items()))
    if model.edge_to_faces != expected_owners:
        errors.append("numbering face edge ownership is inconsistent")
    expected_fusion = frozenset(edge for edge, face_ids in owners.items() if len(face_ids) == 2)
    expected_perimeter = frozenset(edge for edge, face_ids in owners.items() if len(face_ids) == 1)
    if model.fusion_edges != expected_fusion or model.perimeter_edges != expected_perimeter:
        errors.append("numbering face perimeter or fusion edge classification is inconsistent")
    expected_adjacency = tuple(
        sorted((min(face_ids), max(face_ids), edge) for edge, face_ids in owners.items() if len(face_ids) == 2)
    )
    if model.face_adjacency != expected_adjacency:
        errors.append("numbering face adjacency is inconsistent with shared edges")
    boundary_edges = []
    for left, right in zip(model.outer_boundary, model.outer_boundary[1:] + model.outer_boundary[:1]):
        bond = mol.get_bond(left, right)
        if bond is None:
            errors.append("numbering outer boundary is not a molecular cycle")
            return
        boundary_edges.append(bond.idx)
    if frozenset(boundary_edges) != expected_perimeter:
        errors.append("numbering outer boundary does not equal the face-model perimeter")


def _audit_indicated_hydrogens(
    mol: Molecule,
    numbering: FusionNumberingProof,
    model: ParentBondModel,
    cited: tuple[SystemLocant, ...],
    errors: list[str],
    intrinsic_carbon_atoms: frozenset[int] = frozenset(),
    hydro_owned_atoms: frozenset[int] = frozenset(),
) -> None:
    """Audit fusion indicated-H citations against graph and bond-model state."""

    if len(cited) != len(set(cited)):
        errors.append("fusion indicated-hydrogen citations contain duplicate locants")
        return
    selected_map = dict(numbering.input_locant_maps[0])
    atom_by_locant = {locant: atom for atom, locant in selected_map.items()}
    if any(locant not in atom_by_locant for locant in cited):
        errors.append("fusion indicated-hydrogen citation is outside the completed numbering")
        return
    candidates = set(indicated_hydrogen_candidate_atoms(mol, selected_map)) | set(intrinsic_carbon_atoms)
    cited_atoms = {atom_by_locant[locant] for locant in cited}
    if not cited_atoms <= candidates:
        errors.append("fusion indicated-hydrogen citation points to an ineligible graph atom")
    required = {atom for atom in candidates if mol.atoms[atom].symbol != "C"}
    required.update(bond_model_indicated_hydrogen_atoms(mol, model, candidates))
    required.update(intrinsic_carbon_atoms)
    if not required <= cited_atoms | hydro_owned_atoms:
        errors.append("fusion indicated-hydrogen citations omit a graph-required site")


def _audit_bond_model(abstract: FusionGraph, model: ParentBondModel, errors: list[str]) -> None:
    abstract_edges = frozenset(normalize_edge(*bond.atoms) for bond in abstract.bonds)
    known_edges = frozenset(
        normalize_edge(*edge)
        for edge in model.required_single_bonds | model.required_double_bonds | model.pi_eligible_edges
    )
    if known_edges != abstract_edges:
        errors.append("parent bond model does not cover every and only abstract parent edge")
        return

    maximum = 0
    for assignment in model.allowed_kekule_assignments:
        try:
            validate_parent_bond_valence(abstract, assignment)
        except ValueError as exc:
            errors.append(f"parent bond assignment violates fixed valence: {exc}")
        orders = {normalize_edge(*edge): order for edge, order in assignment.orders}
        if set(orders) != abstract_edges:
            errors.append("parent bond assignment is incomplete")
            continue
        if any(order not in {1, 2} for order in orders.values()):
            errors.append("fusion parent bond assignments may contain only single and double bonds")
        double_edges = [edge for edge, order in orders.items() if order == 2]
        maximum = max(maximum, len(double_edges))
        if len({atom for edge in double_edges for atom in edge}) != 2 * len(double_edges):
            errors.append("parent bond assignment contains cumulative double bonds")
        if any(orders[edge] != 1 for edge in model.required_single_bonds):
            errors.append("parent bond assignment violates a required-single edge")
        if any(orders[edge] != 2 for edge in model.required_double_bonds):
            errors.append("parent bond assignment violates a required-double edge")
    if maximum != model.maximum_non_cumulative_double_bonds:
        errors.append("parent bond model double-bond maximum is inconsistent with its assignments")
    if not model.allowed_kekule_assignments:
        errors.append("parent bond model has no allowed bonding assignment")
        return


def _audit_derivative_state(
    mol: Molecule,
    parent_atoms: frozenset[int],
    numbering: FusionNumberingProof,
    model: ParentBondModel,
    indicated_hydrogens: tuple[SystemLocant, ...],
    state: ParentDerivativeState,
    errors: list[str],
) -> None:
    """Verify typed hydro, unsaturation, and oxo operations against the graph."""

    atom_by_locant = {locant: atom for atom, locant in numbering.input_locant_maps[0]}
    indicated_h_atoms = {atom_by_locant[locant] for locant in indicated_hydrogens}
    delta = compare_actual_parent_to_implied_parent(
        mol,
        parent_atoms,
        model,
        externally_unsaturated_atom_ids={operation.parent_atom_id for operation in state.external_pi_operations},
        indicated_hydrogen_atom_ids=indicated_h_atoms,
        atom_to_locant=dict(numbering.input_locant_maps[0]),
    )
    if delta is None or not delta.compatible:
        errors.append("observed parent bond state is incompatible with the parent hydride")
        return
    if state.bond_delta != delta:
        errors.append("typed derivative state does not carry the selected parent bond delta")

    redistribution = prove_pi_redistribution(
        mol,
        parent_atoms,
        model,
        delta,
        indicated_hydrogen_atom_ids=indicated_h_atoms,
        oxo_operations=state.oxo_operations,
        imino_operations=state.imino_operations,
        alkylidene_operations=state.alkylidene_operations,
    )
    if state.pi_redistribution != redistribution:
        errors.append("pi redistribution does not reconstruct the raw delta and final implicit parent state")
    locants = {atom: str(locant) for atom, locant in numbering.input_locant_maps[0]}
    expected_hydrogenated_atoms = sorted(
        redistribution.hydrogenated_atom_ids if redistribution else delta.hydrogenated_atom_ids,
        key=lambda atom: system_locant_sort_key(locants[atom]),
    )
    expected_hydrogenated_bonds = tuple(sorted(mol.get_bond(*edge).idx for edge in delta.hydrogenated_edges))
    if redistribution:
        expected_hydrogenated_bonds = tuple(sorted(redistribution.removed_bond_ids | redistribution.added_bond_ids))
    if expected_hydrogenated_atoms:
        if len(state.hydro_operations) != 1:
            errors.append("hydrogenated parent edges require one typed hydro operation")
        else:
            operation = state.hydro_operations[0]
            if (
                operation.operation_kind != "additive_hydrogen"
                or operation.atom_ids != tuple(expected_hydrogenated_atoms)
                or operation.locants != tuple(locants[atom] for atom in expected_hydrogenated_atoms)
                or operation.bond_ids != expected_hydrogenated_bonds
            ):
                errors.append("typed hydro operation does not exactly represent hydrogenated parent edges")
    elif state.hydro_operations:
        errors.append("typed hydro operations exist without hydrogenated parent edges")

    expected_unsaturation = {
        (
            bond_id,
            mol.bonds[bond_id].order,
            frozenset((mol.bonds[bond_id].u, mol.bonds[bond_id].v)),
        )
        for bond_id in (delta.additional_multiple_bond_ids if redistribution is None else ())
    }
    observed_unsaturation = {
        (operation.bond_id, operation.bond_order, frozenset(operation.atom_ids))
        for operation in state.unsaturation_operations
    }
    if len(observed_unsaturation) != len(state.unsaturation_operations):
        errors.append("typed unsaturation operations duplicate a parent bond")
    if observed_unsaturation != expected_unsaturation:
        errors.append("typed unsaturation operations do not represent the parent bond delta")
    if any(
        operation.locants != tuple(locants[atom] for atom in operation.atom_ids)
        for operation in state.unsaturation_operations
    ):
        errors.append("typed unsaturation operation locants do not match completed-system numbering")

    expected_oxo = {
        (parent_atom, neighbor, bond.idx, locants[parent_atom])
        for parent_atom in parent_atoms
        for neighbor in mol.get_neighbors(parent_atom)
        if neighbor not in parent_atoms
        and mol.atoms[neighbor].symbol == "O"
        and (bond := mol.get_bond(parent_atom, neighbor)) is not None
        and bond.order == 2
    }
    observed_oxo = {
        (operation.parent_atom_id, operation.oxygen_atom_id, operation.bond_id, operation.locant)
        for operation in state.oxo_operations
    }
    if len(observed_oxo) != len(state.oxo_operations):
        errors.append("typed oxo operations duplicate an exocyclic parent oxo group")
    if observed_oxo != expected_oxo:
        errors.append("typed oxo operations do not represent every exocyclic parent oxo group")

    for symbol, operations in (("N", state.imino_operations), ("C", state.alkylidene_operations)):
        expected = {
            (parent, neighbor, mol.get_bond(parent, neighbor).idx, locants[parent])
            for parent in parent_atoms
            for neighbor in mol.get_neighbors(parent)
            if neighbor not in parent_atoms
            and mol.atoms[neighbor].symbol == symbol
            and is_neutral_external_pi_ligand(mol, parent, neighbor)
        }
        observed = {
            (operation.parent_atom_id, operation.external_atom_id, operation.bond_id, operation.locant)
            for operation in operations
        }
        if len(observed) != len(operations) or observed != expected:
            errors.append(f"typed external {symbol} operations do not represent every supported exocyclic bond")


def _error(message: str, *, checks: Iterable[str] = ()) -> FusionAuditResult:
    return FusionAuditResult(AuditStatus.ERROR, checks=tuple(checks), errors=(message,))
