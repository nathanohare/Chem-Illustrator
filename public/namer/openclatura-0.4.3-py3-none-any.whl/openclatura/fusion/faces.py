"""Graph-native bounded-face discovery for fused ring systems.

The routines in this module use only :class:`~openclatura.molecule.Molecule`
connectivity.  They deliberately avoid drawing coordinates: a candidate face
model is accepted only when its cycles provide a complete combinatorial proof
for the selected molecular subgraph.
"""

from __future__ import annotations

from collections import Counter, defaultdict
from collections.abc import Iterable
from dataclasses import dataclass
from itertools import combinations

from ..canonical_ranks import canonical_ranks
from ..graph_kernel import cycle_rank as graph_cycle_rank
from ..graph_kernel import gf2_basis_insert
from ..molecule import Molecule, edges_within_atoms
from ..polycycle_topology import (
    adjacency_from_edges,
    canonical_cycle,
    connected_components,
    cycle_edges,
    normalize_edge,
)
from .config import fusion_nomenclature_config
from .model import Face, FaceModel

_CONFIG = fusion_nomenclature_config()

Edge = tuple[int, int]


class FaceSearchBudgetExceeded(RuntimeError):
    """Raised rather than returning an unsafe partial cycle/face result."""

    def __init__(self, phase: str, budget: int) -> None:
        super().__init__(f"{phase} search exceeded its budget of {budget} states")
        self.phase = phase
        self.budget = budget


@dataclass(frozen=True, slots=True)
class GraphCycle:
    """A simple cycle in canonical atom order."""

    atoms: tuple[int, ...]
    edges: frozenset[Edge]

    @classmethod
    def from_atoms(cls, atoms: Iterable[int]) -> GraphCycle:
        canonical = canonical_cycle(tuple(atoms))
        if len(canonical) < 3 or len(set(canonical)) != len(canonical):
            raise ValueError("A graph cycle needs at least three distinct atoms")
        return cls(atoms=canonical, edges=frozenset(cycle_edges(canonical)))


@dataclass(frozen=True, slots=True)
class FaceModelAudit:
    """Evidence collected while validating one bounded-face model."""

    ok: bool
    errors: tuple[str, ...]
    cycle_rank: int
    edge_multiplicity: tuple[tuple[Edge, int], ...]
    dual_adjacency: tuple[tuple[int, tuple[int, ...]], ...]
    outer_boundary: tuple[int, ...]
    reconstructed_edges: frozenset[Edge]


@dataclass(frozen=True, slots=True)
class BoundedFaceModel:
    """A deterministic, audited set of bounded faces for a ring graph."""

    atom_ids: frozenset[int]
    edge_ids: frozenset[Edge]
    faces: tuple[GraphCycle, ...]
    outer_boundary: GraphCycle
    cycle_rank: int
    audit: FaceModelAudit

    @property
    def peripheral_atoms(self) -> frozenset[int]:
        return frozenset(self.outer_boundary.atoms)

    @property
    def interior_atoms(self) -> frozenset[int]:
        return self.atom_ids - self.peripheral_atoms

    @property
    def face_membership_by_atom(self) -> tuple[tuple[int, tuple[int, ...]], ...]:
        owners: dict[int, list[int]] = {atom: [] for atom in self.atom_ids}
        for face_id, face in enumerate(self.faces):
            for atom in face.atoms:
                owners[atom].append(face_id)
        return tuple((atom, tuple(face_ids)) for atom, face_ids in sorted(owners.items()))

    @property
    def fusion_atoms(self) -> frozenset[int]:
        return frozenset(atom for atom, face_ids in self.face_membership_by_atom if len(face_ids) > 1)


def typed_face_model(mol: Molecule, bounded: BoundedFaceModel) -> FaceModel:
    """Translate a bounded-face proof into the bond-ID model used by layouts."""

    owners: dict[int, list[int]] = defaultdict(list)
    faces = []
    for face_id, cycle in enumerate(bounded.faces):
        edge_cycle = tuple(mol.get_bond(left, right).idx for left, right in cycle_edges(cycle.atoms))
        faces.append(Face(face_id, cycle.atoms, edge_cycle, len(cycle.atoms)))
        for edge_id in edge_cycle:
            owners[edge_id].append(face_id)
    perimeter = frozenset(edge for edge, face_ids in owners.items() if len(face_ids) == 1)
    fusion = frozenset(edge for edge, face_ids in owners.items() if len(face_ids) == 2)
    adjacency = []
    for edge, face_ids in sorted(owners.items()):
        if len(face_ids) == 2:
            adjacency.append((face_ids[0], face_ids[1], edge))
    return FaceModel(
        faces=tuple(faces),
        edge_to_faces=tuple(sorted((edge, tuple(sorted(face_ids))) for edge, face_ids in owners.items())),
        perimeter_edges=perimeter,
        fusion_edges=fusion,
        outer_boundary=bounded.outer_boundary.atoms,
        face_adjacency=tuple(sorted(adjacency)),
    )


@dataclass(slots=True)
class _Budget:
    phase: str
    limit: int
    used: int = 0

    def spend(self) -> None:
        self.used += 1
        if self.used > self.limit:
            raise FaceSearchBudgetExceeded(self.phase, self.limit)


def enumerate_chordless_cycles(
    mol: Molecule,
    atom_ids: Iterable[int] | None = None,
    *,
    min_size: int = _CONFIG.search.minimum_ring_size,
    max_size: int = _CONFIG.search.maximum_ring_size,
    search_budget: int = _CONFIG.search.cycle_states,
) -> tuple[GraphCycle, ...]:
    """Enumerate chordless cycles deterministically within a hard budget.

    ``min_size`` and ``max_size`` are intentionally constrained to the first
    production range, 3 through 8.  Exhausting the budget raises instead of
    exposing a partial cycle set that could be mistaken for a proof.
    """

    if not _CONFIG.search.minimum_ring_size <= min_size <= max_size <= _CONFIG.search.maximum_ring_size:
        raise ValueError(
            f"cycle sizes must satisfy {_CONFIG.search.minimum_ring_size} <= min_size <= "
            f"max_size <= {_CONFIG.search.maximum_ring_size}"
        )
    if search_budget < 1:
        raise ValueError("search_budget must be positive")
    atoms = frozenset(mol.atoms if atom_ids is None else atom_ids)
    unknown = atoms - mol.atoms.keys()
    if unknown:
        raise KeyError(f"Unknown atom ids: {sorted(unknown)}")
    adjacency = {
        atom: tuple(sorted(neighbor for neighbor in mol.get_neighbors(atom) if neighbor in atoms))
        for atom in sorted(atoms)
    }
    budget = _Budget("cycle enumeration", search_budget)
    found: dict[tuple[int, ...], GraphCycle] = {}

    for start in sorted(atoms):
        _enumerate_from_start(start, adjacency, min_size, max_size, budget, found)

    return tuple(sorted(found.values(), key=lambda cycle: (len(cycle.atoms), cycle.atoms)))


def audit_bounded_face_model(
    mol: Molecule,
    atom_ids: Iterable[int],
    faces: Iterable[GraphCycle | Iterable[int]],
) -> FaceModelAudit:
    """Audit whether ``faces`` exactly prove a bounded-face decomposition."""

    atoms = frozenset(atom_ids)
    graph_edges = frozenset(edges_within_atoms(mol, set(atoms)))
    normalized_faces = tuple(_as_cycle(face) for face in faces)
    errors: list[str] = []

    if not atoms:
        errors.append("ring graph is empty")
        rank = 0
    elif not _is_connected(atoms, graph_edges):
        errors.append("ring graph is disconnected")
        rank = len(graph_edges) - len(atoms) + _component_count(atoms, graph_edges)
    else:
        rank = len(graph_edges) - len(atoms) + 1
    if len(normalized_faces) != rank:
        errors.append(f"bounded face count {len(normalized_faces)} does not equal cycle rank {rank}")

    multiplicity: Counter[Edge] = Counter()
    for face_index, face in enumerate(normalized_faces):
        if not set(face.atoms) <= atoms:
            errors.append(f"face {face_index} contains atoms outside the ring graph")
        if not face.edges <= graph_edges:
            errors.append(f"face {face_index} contains edges outside the ring graph")
        if not _is_chordless_for_edges(face, graph_edges):
            errors.append(f"face {face_index} is not chordless")
        multiplicity.update(face.edges)

    reconstructed = frozenset(multiplicity)
    if reconstructed != graph_edges:
        errors.append("bounded faces do not exactly reconstruct the ring-graph edges")
    if any(count > 2 for count in multiplicity.values()):
        errors.append("a ring-graph edge belongs to more than two bounded faces")

    dual = _dual_adjacency(normalized_faces)
    if normalized_faces and not _dual_is_connected(dual):
        errors.append("bounded-face dual graph is disconnected")

    boundary_edges = frozenset(edge for edge, count in multiplicity.items() if count % 2 == 1)
    outer_boundary = _simple_cycle_order(boundary_edges)
    if outer_boundary is None:
        errors.append("XOR outer boundary is not a simple cycle")

    return FaceModelAudit(
        ok=not errors,
        errors=tuple(errors),
        cycle_rank=rank,
        edge_multiplicity=tuple(sorted(multiplicity.items())),
        dual_adjacency=tuple((index, dual[index]) for index in range(len(normalized_faces))),
        outer_boundary=outer_boundary or (),
        reconstructed_edges=reconstructed,
    )


def select_bounded_face_model(
    mol: Molecule,
    atom_ids: Iterable[int],
    *,
    min_ring_size: int = _CONFIG.search.minimum_ring_size,
    max_ring_size: int | None = None,
    cycle_search_budget: int = _CONFIG.search.cycle_states,
    model_search_budget: int = _CONFIG.search.face_model_states,
) -> BoundedFaceModel | None:
    """Return the first deterministic face model satisfying every audit.

    Candidates are ordered by total face perimeter and then canonical cycle
    order.  This favors elementary bounded faces without relying on geometry.
    ``None`` means that the completed search found no proven model; budget
    exhaustion remains an exception and is never conflated with no model.
    An explicit ring-size override confines the ordinary cycle search; only
    the default policy enables the linear carbon bicycle proof and bounded
    carbon-face completion of otherwise uncovered edges.
    """

    if cycle_search_budget < 1 or model_search_budget < 1:
        raise ValueError("face search budgets must be positive")
    atoms = frozenset(atom_ids)
    graph_edges = frozenset(edges_within_atoms(mol, set(atoms)))
    try:
        rank = graph_cycle_rank(atoms, graph_edges)
    except ValueError:
        return None
    if rank < 1:
        return None
    if rank == 2 and min_ring_size == _CONFIG.search.minimum_ring_size and max_ring_size is None:
        ordinary = _larger_carbon_bicycle(mol, atoms, graph_edges)
        if ordinary is not None:
            return ordinary
    cycles = enumerate_chordless_cycles(
        mol,
        atoms,
        min_size=min_ring_size,
        max_size=_CONFIG.search.maximum_ring_size if max_ring_size is None else max_ring_size,
        search_budget=cycle_search_budget,
    )
    if rank > 2 and min_ring_size == _CONFIG.search.minimum_ring_size and max_ring_size is None:
        cycles = _complete_large_carbon_faces(mol, atoms, graph_edges, cycles, cycle_search_budget)
    budget = _Budget("face-model selection", model_search_budget)
    ranks = canonical_ranks(mol, atoms)
    valid: list[tuple[tuple, BoundedFaceModel]] = []
    for face_indices in _independent_face_sets(cycles, graph_edges, rank, budget):
        selected = tuple(cycles[index] for index in face_indices)
        audit = audit_bounded_face_model(mol, atoms, selected)
        if not audit.ok:
            continue
        outer = GraphCycle.from_atoms(audit.outer_boundary)
        model = BoundedFaceModel(
            atom_ids=atoms,
            edge_ids=graph_edges,
            faces=selected,
            outer_boundary=outer,
            cycle_rank=rank,
            audit=audit,
        )
        score = _face_model_score(selected, ranks)
        valid.append((score, model))
    if not valid:
        return None
    best_score = min(score for score, _ in valid)
    best = [model for score, model in valid if score == best_score]
    distinct = {frozenset(face.edges for face in model.faces) for model in best}
    return best[0] if len(distinct) == 1 else None


def _complete_large_carbon_faces(
    mol: Molecule,
    atoms: frozenset[int],
    edges: frozenset[Edge],
    cycles: tuple[GraphCycle, ...],
    search_budget: int,
) -> tuple[GraphCycle, ...]:
    """Complete uncovered edges with bounded, edge-seeded annulene candidates.

    Small-ring coverage is unchanged. A missing edge must lie on a supported
    neutral carbon face; the full face-set reconstruction still decides whether
    any candidate is actually a face rather than a larger perimeter cycle.
    """

    if not _CONFIG.annulene_ring_sizes:
        return cycles
    missing = edges - frozenset(edge for cycle in cycles for edge in cycle.edges)
    if not missing:
        return cycles
    carbon_atoms = {atom for atom in atoms if mol.atoms[atom].symbol == "C" and not mol.atoms[atom].charge}
    if any(not set(edge) <= carbon_atoms for edge in missing):
        return cycles
    adjacency = _adjacency(carbon_atoms, (edge for edge in edges if set(edge) <= carbon_atoms))
    found: dict[tuple[int, ...], GraphCycle] = {}
    budget = _Budget("large carbon face completion", search_budget)
    for start, neighbor in sorted(missing):
        _enumerate_from_start(
            start,
            adjacency,
            _CONFIG.search.maximum_ring_size + 1,
            max(_CONFIG.annulene_ring_sizes),
            budget,
            found,
            seed_neighbor=neighbor,
        )
    return tuple(sorted((*cycles, *found.values()), key=lambda cycle: (len(cycle.atoms), cycle.atoms)))


def _larger_carbon_bicycle(mol: Molecule, atoms: frozenset[int], edges: frozenset[Edge]) -> BoundedFaceModel | None:
    """Walk the two degree-two paths beside one shared edge in linear time."""

    if not _CONFIG.annulene_ring_sizes or any(
        mol.atoms[atom].symbol != "C" or mol.atoms[atom].charge for atom in atoms
    ):
        return None
    adjacency = adjacency_from_edges(atoms, edges)
    junctions = [atom for atom, neighbors in adjacency.items() if len(neighbors) == 3]
    if len(junctions) != 2 or any(len(neighbors) not in {2, 3} for neighbors in adjacency.values()):
        return None
    start, end = junctions
    if end not in adjacency[start]:
        return None
    paths = []
    seen = {start, end}
    for first in adjacency[start]:
        if first == end:
            continue
        path = [start]
        previous, current = start, first
        while current != end:
            if current in seen:
                return None
            seen.add(current)
            path.append(current)
            following = [atom for atom in adjacency[current] if atom != previous]
            if len(following) != 1:
                return None
            previous, current = current, following[0]
        paths.append((*path, end))
    sizes = tuple(map(len, paths))
    if (
        seen != atoms
        or len(paths) != 2
        or max(sizes) not in _CONFIG.annulene_ring_sizes
        or max(sizes) <= _CONFIG.search.maximum_ring_size
        or min(sizes) < _CONFIG.rules.minimum_ring_size
    ):
        return None
    faces = tuple(
        sorted((GraphCycle.from_atoms(path) for path in paths), key=lambda face: (len(face.atoms), face.atoms))
    )
    audit = audit_bounded_face_model(mol, atoms, faces)
    if not audit.ok:
        return None
    return BoundedFaceModel(atoms, edges, faces, GraphCycle.from_atoms(audit.outer_boundary), 2, audit)


def cached_bounded_face_model(
    mol: Molecule,
    atom_ids: Iterable[int],
    *,
    min_ring_size: int = _CONFIG.search.minimum_ring_size,
    max_ring_size: int | None = None,
    cycle_search_budget: int = _CONFIG.search.cycle_states,
    model_search_budget: int = _CONFIG.search.face_model_states,
) -> BoundedFaceModel | None:
    """Reuse one immutable face proof across fusion naming alternatives."""

    atoms = frozenset(atom_ids)
    cache_key = (
        "bounded_face_model",
        tuple(sorted(atoms)),
        min_ring_size,
        max_ring_size,
        cycle_search_budget,
        model_search_budget,
    )
    if cache_key not in mol._fusion_plan_cache:
        mol._fusion_plan_cache[cache_key] = select_bounded_face_model(
            mol,
            atoms,
            min_ring_size=min_ring_size,
            max_ring_size=max_ring_size,
            cycle_search_budget=cycle_search_budget,
            model_search_budget=model_search_budget,
        )
    return mol._fusion_plan_cache[cache_key]


def _independent_face_sets(
    cycles: tuple[GraphCycle, ...],
    graph_edges: frozenset[Edge],
    target_rank: int,
    budget: _Budget,
) -> tuple[tuple[int, ...], ...]:
    """Enumerate complete face sets with edge-pivot and GF(2) pruning.

    The old combinations loop paid for every size-``target_rank`` subset even
    when an early edge could no longer be covered.  This search branches on
    the least-supported uncovered edge, maintains edge multiplicities, and
    rejects linearly dependent cycle vectors before a full face audit.
    """

    if target_rank <= 0 or len(cycles) < target_rank:
        return ()
    edge_order = tuple(sorted(graph_edges))
    edge_position = {edge: index for index, edge in enumerate(edge_order)}
    masks = tuple(sum(1 << edge_position[edge] for edge in cycle.edges) for cycle in cycles)
    candidates_by_edge = tuple(
        tuple(index for index, mask in enumerate(masks) if mask & (1 << position))
        for position in range(len(edge_order))
    )
    all_edges_mask = (1 << len(edge_order)) - 1
    results: set[tuple[int, ...]] = set()
    visited: set[frozenset[int]] = set()

    def visit(
        selected: frozenset[int],
        covered_once: int,
        covered_twice: int,
        basis: tuple[int, ...],
    ) -> None:
        budget.spend()
        if selected in visited:
            return
        visited.add(selected)
        if len(selected) == target_rank:
            if covered_once == all_edges_mask:
                results.add(tuple(sorted(selected)))
            return
        if len(selected) > target_rank:
            return

        remaining_slots = target_rank - len(selected)
        uncovered = all_edges_mask ^ covered_once
        if uncovered:
            uncovered_positions = tuple(position for position in range(len(edge_order)) if uncovered & (1 << position))
            pivot = min(
                uncovered_positions,
                key=lambda position: (
                    sum(index not in selected for index in candidates_by_edge[position]),
                    position,
                ),
            )
            choices = tuple(index for index in candidates_by_edge[pivot] if index not in selected)
            possible = 0
            for index, mask in enumerate(masks):
                if index not in selected:
                    possible |= mask
            if uncovered & ~possible:
                return
        else:
            # Every edge is drawn and the face set is still short. A face of a
            # pericondensed system can be enclosed by its neighbours, sharing
            # every one of its edges and contributing none of its own, so a
            # complete cover is reached before the last faces are chosen --
            # coronene's central ring is the smallest case. There is no
            # uncovered edge to pivot on, so the remaining faces are the
            # candidates, and the independence and twice-covered tests below
            # still decide which of them can belong to the model.
            choices = tuple(index for index in range(len(cycles)) if index not in selected)
        if not choices:
            return

        for index in choices:
            mask = masks[index]
            if covered_twice & mask:
                continue
            next_basis = gf2_basis_insert(basis, mask)
            if next_basis is None:
                continue
            new_twice = covered_twice | (covered_once & mask)
            new_once = covered_once | mask
            if remaining_slots == 1 and new_once != all_edges_mask:
                continue
            visit(selected | {index}, new_once, new_twice, next_basis)

    visit(frozenset(), 0, 0, ())
    return tuple(sorted(results))


def _face_model_score(faces: tuple[GraphCycle, ...], ranks: dict[int, int]) -> tuple:
    """Rank face models without consulting input atom identifiers."""

    signatures = tuple(sorted(_cycle_rank_signature(face.atoms, ranks) for face in faces))
    return sum(len(face.atoms) for face in faces), signatures


def _cycle_rank_signature(cycle: tuple[int, ...], ranks: dict[int, int]) -> tuple[int, ...]:
    values = tuple(ranks[atom] for atom in cycle)
    variants = []
    for direction in (values, tuple(reversed(values))):
        variants.extend(direction[offset:] + direction[:offset] for offset in range(len(direction)))
    return min(variants)


def _as_cycle(face: GraphCycle | Iterable[int]) -> GraphCycle:
    return face if isinstance(face, GraphCycle) else GraphCycle.from_atoms(face)


def _enumerate_from_start(
    start: int,
    adjacency: dict[int, tuple[int, ...]],
    min_size: int,
    max_size: int,
    budget: _Budget,
    found: dict[tuple[int, ...], GraphCycle],
    *,
    seed_neighbor: int | None = None,
) -> None:
    path = [start] if seed_neighbor is None else [start, seed_neighbor]
    visited = set(path)

    def search(current: int) -> None:
        budget.spend()
        for neighbor in adjacency[current]:
            if neighbor == start:
                if len(path) >= min_size:
                    cycle = GraphCycle.from_atoms(path)
                    if _is_chordless(cycle, adjacency):
                        found[cycle.atoms] = cycle
                continue
            # Making ``start`` the smallest cycle atom removes rotational
            # duplicates before canonicalization and prunes the search.
            if (seed_neighbor is None and neighbor < start) or neighbor in visited or len(path) >= max_size:
                continue
            if seed_neighbor is not None and any(atom in visited - {current, start} for atom in adjacency[neighbor]):
                continue
            visited.add(neighbor)
            path.append(neighbor)
            search(neighbor)
            path.pop()
            visited.remove(neighbor)

    search(path[-1])


def _is_chordless(cycle: GraphCycle, adjacency: dict[int, tuple[int, ...]]) -> bool:
    induced = {
        normalize_edge(atom, neighbor)
        for atom in cycle.atoms
        for neighbor in adjacency[atom]
        if neighbor in cycle.atoms and atom < neighbor
    }
    return induced == set(cycle.edges)


def _is_chordless_for_edges(cycle: GraphCycle, graph_edges: frozenset[Edge]) -> bool:
    cycle_atoms = set(cycle.atoms)
    induced = {edge for edge in graph_edges if edge[0] in cycle_atoms and edge[1] in cycle_atoms}
    return induced == set(cycle.edges)


def _adjacency(atoms: Iterable[int], edges: Iterable[Edge]) -> dict[int, tuple[int, ...]]:
    atom_set = frozenset(atoms)
    edge_set = frozenset(edges)
    return {atom: tuple(sorted(neighbors)) for atom, neighbors in adjacency_from_edges(atom_set, edge_set).items()}


def _is_connected(atoms: frozenset[int], edges: frozenset[Edge]) -> bool:
    return bool(atoms) and len(connected_components(set(atoms), edges)) == 1


def _component_count(atoms: frozenset[int], edges: frozenset[Edge]) -> int:
    return len(connected_components(set(atoms), edges))


def _dual_adjacency(faces: tuple[GraphCycle, ...]) -> dict[int, tuple[int, ...]]:
    neighbors: dict[int, list[int]] = {index: [] for index in range(len(faces))}
    for left, right in combinations(range(len(faces)), 2):
        if faces[left].edges & faces[right].edges:
            neighbors[left].append(right)
            neighbors[right].append(left)
    return {index: tuple(values) for index, values in neighbors.items()}


def _dual_is_connected(adjacency: dict[int, tuple[int, ...]]) -> bool:
    if not adjacency:
        return False
    stack = [0]
    seen: set[int] = set()
    while stack:
        index = stack.pop()
        if index in seen:
            continue
        seen.add(index)
        stack.extend(neighbor for neighbor in adjacency[index] if neighbor not in seen)
    return len(seen) == len(adjacency)


def _simple_cycle_order(edges: frozenset[Edge]) -> tuple[int, ...] | None:
    if len(edges) < 3:
        return None
    atoms = frozenset(atom for edge in edges for atom in edge)
    adjacency = _adjacency(atoms, edges)
    if any(len(neighbors) != 2 for neighbors in adjacency.values()) or not _is_connected(atoms, edges):
        return None
    start = min(atoms)
    variants = []
    for first in adjacency[start]:
        order = [start]
        previous: int | None = None
        current = start
        nxt = first
        while nxt != start:
            if nxt in order:
                return None
            order.append(nxt)
            previous, current = current, nxt
            choices = [neighbor for neighbor in adjacency[current] if neighbor != previous]
            if len(choices) != 1:
                return None
            nxt = choices[0]
        if len(order) != len(atoms):
            return None
        variants.append(tuple(order))
    return min(variants)
